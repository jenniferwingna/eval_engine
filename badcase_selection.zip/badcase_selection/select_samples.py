#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""select_samples_v2.py — 样本选取引擎 v2（权威字段逐条校验 + 分层多样性抽样）。

相对 v1 的两处根本改动：

一、权威字段判定：从"均值对齐"改为"三重校验"
  v1 只比较 mean(score) 与 metrics.accuracy。均值只是一阶矩，有三个漏洞：
    (a) 巧合对齐：score 若与真值相反，mean(score) = 1 - acc；acc≈0.5 时两者
        恰好相等，反向字段会被当成权威。
    (b) 量纲不一致：judge 0-5 分的均值（如 3.2）永远对不上 [0,1] 的 accuracy
        （如 0.64），judge5 bkey 永远拿不到 score 权威。
    (c) 口径不一致：accuracy 若是按 subtask 宏平均、或剔除了打分失败的样本，
        逐条均值会"合法地"对不上，导致误杀。
  v2 做法：
    ① 多口径重算：对每个候选字段，分别按 {全量/剔除打分失败} × {微平均/
       subtask 宏平均}，以及 judge 型的 {score/5, score≥阈值比例} 重算，
       任一口径与 accuracy 对齐即记录命中口径（audit.matched_by）。
    ② 方向校验（逐条）：score 与 correct 同时存在时，算逐条一致率；
       一致率 < 0.5 说明二者方向相反，用"锚点"裁决谁是对的。
    ③ 锚点校验：输出规范化后与 GT 完全相等的样本"必然是 pass"，
       用它们检查权威字段的方向；锚点判 pass 率 < 0.8 → 撤销权威。
    acc≈0.5 且无锚点/无交叉字段可裁决时，标 ambiguous 警告（不跳过，但提示人审）。

二、选取策略：从"最差 top-N"改为"分层配额 + 严重度/多样性权衡"
  v1 的问题：top-N 最差会扎堆在同一个最弱 subtask、同一种失败形态，
  而且极端最差往往是数据问题（GT 错、音频坏），不代表模型的典型错误；
  judge 型大量并列 0 分时，sort 是稳定排序，等于"按文件顺序取前 N"。
  v2 做法：
    ① 分层：按 subtask 分层（bkey 内只有一个 subtask 时退化为按失败签名分层）。
    ② 配额：每层先保底 1 条（覆盖），剩余名额按 --alloc 分配：
         prop    按该层 badcase 数成比例（反映"哪里错得多"）
         sqrt    按 sqrt(数量)（默认；介于比例与均匀之间的经典折中）
         uniform 均匀（偏向覆盖稀有层）
       层数 > 名额时，按权重无放回抽取 N 个层。
    ③ 层内 MMR（最大边际相关）：每次选 λ·严重度 − (1−λ)·与已选样本最大相似度
       最高的一条；相似度 = 输出文本字符 3-gram Jaccard 与失败签名一致度的加权。
       可选 --dup-thr 硬去重（默认关：选择题输出都是 "A" 时，文本相同≠case 相同）。
    ④ 失败签名（无需模型，纯规则）：长度带（偏短/正常/偏长）、复读循环、
       语种错配、严重度带。签名分布写进 audit，可直接看"抽样是否代表了池子"。
    ⑤ 排除已有 case 在抽样前做（v1 在截断后才排除，会导致实际条数不足 N）。

用法：
  python3 select_samples_v2.py --base <raw_out> --out <plan.json> \
      [--top-n 10] [--seed 42] [--alloc sqrt] [--lam 0.5] \
      [--exclude-dirs <包1>:<包2>] [--bkeys k1,k2] [--no-empty]

三、回归对比模式（--baseline <旧 ckpt 的 raw_out>）
  只保留"baseline 判 pass、本批判 bad"的翻转 case（新增 badcase）。同一 case 前后
  两个 ckpt 对照着看，比两批各自随机抽 10 条更能说明"这次改坏了什么"。
  注意：--exclude-dirs 只应排除【同一 ckpt】已组过包的 case；跨 ckpt 排除会让
  你永远看不到同一条 case 的前后对比。

候选池模式：给后续模型判因（triage_judge.py）用时，--top-n 设为最终条数的 3~5 倍，
产出的是"候选池"，最终精选由 triage_judge.py 按根因分层完成。

plan.json 的 plan[] 行与 v1 字段兼容（assemble_pkg.py 可直接用），新增
stratum / severity / signature / max_sim 字段；audit[] 新增 matched_by、
anchor_*、agree_*、coverage 等审计字段。
"""
import argparse
import fnmatch
import json
import math
import os
import random
import re
import statistics
from collections import Counter, defaultdict

ACC_TOL = 0.01
ANCHOR_MIN = 5            # 锚点少于这个数不做锚点裁决
ANCHOR_PASS_MIN = 0.8     # 锚点被判 pass 的最低比例
ASR_BKEYS = {"wenet_net", "wenet_meeting", "librispeech",
             "twinkstart_speechio_duplex", "twinkstart_kespeech_duplex"}
REASON_KEYS = ("judge_reason", "reason", "rationale", "explanation", "judge_output", "critique")
FAIL_STATUS_PAT = re.compile(r"fail|error|skip|timeout|invalid", re.I)


# ─────────────────────────── 数据读取（与 v1 同源） ───────────────────────────

def load_ledger(base, bkey):
    out = {}
    with open(f"{base}/_ledgers/{bkey}/ledger_v1.0.jsonl") as f:
        for line in f:
            if line.strip():
                d = json.loads(line)
                out[d["id"]] = d
    return out


def resolve_bare_id(sid, ledger_ids, bkey=""):
    cands = [sid]
    if sid.startswith("udss_"):
        cands.append(sid[5:])
    for pref in ("twinkstart_speechio", "twinkstart_kespeech", "librispeech"):
        if sid.startswith(pref + "_"):
            cands.append(sid[len(pref) + 1:])
    if bkey and sid.startswith(bkey + "_"):
        cands.append(sid[len(bkey) + 1:])
    for c in cands:
        if c in ledger_ids:
            return c
    return None


def as_text(t):
    """GT / 输出可能是结构化的（BFCL 的 list、时间轴 JSON），统一转成字符串再比较。"""
    if t is None:
        return ""
    return t if isinstance(t, str) else json.dumps(t, ensure_ascii=False, sort_keys=True)


def norm_zh(t):
    t = re.sub(r"\s+", "", as_text(t))
    return re.sub(r"[，。！？、；：“”‘’《》（）…—,.!?;:()<>\-]", "", t)


def norm_en(t):
    t = as_text(t).upper()
    t = re.sub(r"[^A-Z' ]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def norm_lang(t, lang):
    return norm_en(t) if lang == "en" else norm_zh(t)


def edit_distance(a, b):
    try:
        import editdistance
        return editdistance.eval(a, b)
    except ImportError:
        prev = list(range(len(b) + 1))
        for i in range(1, len(a) + 1):
            cur = [i] + [0] * len(b)
            for j in range(1, len(b) + 1):
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1,
                             prev[j - 1] + (a[i - 1] != b[j - 1]))
            prev = cur
        return prev[-1]


def per_case_mer(ref, hyp, lang):
    r, h = norm_lang(ref, lang), norm_lang(hyp, lang)
    if lang == "en":
        r, h = r.split(), h.split()
    if not r:
        return None
    return edit_distance(h, r) / len(r) * 100.0


def ledger_lang(rec):
    return (rec.get("language") or ["zh"])[0]


def ledger_gt(rec):
    return rec.get("scores", {}).get("ground_truth") or rec.get("metadata", {}).get("reference", "")


def ledger_subtask(rec):
    st = rec.get("metadata", {}).get("subtask")
    if st:
        return st
    m = re.match(r"^(?:vcb|car_reject_zh|voicebench)_[^_]+_(.+?)_\d+$", rec.get("id", ""))
    return m.group(1) if m else None


def sample_output(s):
    return as_text(s.get("raw_output") or s.get("parsed_answer") or "").strip()


def as_bool(v):
    return v in (True, 1, "1", "true", "True")


def as_float(v):
    try:
        return float(v) if v is not None and v != "" else None
    except (TypeError, ValueError):
        return None


def status_ok(s):
    st = s.get("scoring_status")
    return not (st and FAIL_STATUS_PAT.search(str(st)))


# ─────────────────────────── 评分尺度 ───────────────────────────

def detect_scale(scores):
    if not scores:
        return "none"
    vals = set(round(x, 4) for x in scores)
    if vals <= {0.0, 1.0}:
        return "binary"
    mx = max(scores)
    if mx <= 1.0:
        return "unit"        # [0,1] 连续分（v1 会误判成 judge5，导致全部判 bad）
    if mx <= 5.0:
        return "judge5"
    return "other"


def score_pass(sc, scale, judge_pass):
    if scale in ("binary", "unit"):
        return sc >= 0.5
    if scale == "judge5":
        return sc >= judge_pass
    return None


def severity_of_score(sc, scale, judge_pass):
    """失败严重度 ∈ [0,1]，越大越严重。"""
    if sc is None:
        return 1.0
    if scale == "binary":
        return 1.0
    if scale == "unit":
        return max(0.0, min(1.0, 1.0 - sc))
    if scale == "judge5":
        return max(0.0, min(1.0, (judge_pass - sc) / judge_pass))
    return 1.0


# ─────────────────────────── 权威字段：三重校验 ───────────────────────────

def _mean(xs):
    return statistics.fmean(xs) if xs else None


def _macro(pairs):
    """pairs: [(subtask, value)] → subtask 宏平均"""
    g = defaultdict(list)
    for st, v in pairs:
        g[st].append(v)
    if len(g) < 2:
        return None
    return statistics.fmean(statistics.fmean(v) for v in g.values())


def profile_bkey(bkey, metrics_doc, samples, led, args):
    m = metrics_doc.get("metrics", {})
    acc = as_float(m.get("accuracy"))
    is_asr = bkey in ASR_BKEYS

    rows = []   # (sample, bare, subtask, ok, score, correct_present, correct, anchor)
    for s in samples:
        bare = resolve_bare_id(s["sample_id"], led, bkey)
        rec = led.get(bare) if bare else None
        st = ledger_subtask(rec) if rec else None
        lang = ledger_lang(rec) if rec else "zh"
        out, gt = sample_output(s), (ledger_gt(rec) if rec else "")
        anchor = bool(gt) and bool(out) and norm_lang(out, lang) == norm_lang(gt, lang)
        rows.append({
            "s": s, "st": st, "ok": status_ok(s),
            "score": as_float(s.get("score")),
            "has_correct": s.get("correct") is not None,
            "correct": as_bool(s.get("correct")),
            "anchor": anchor,
        })

    scores = [r["score"] for r in rows if r["score"] is not None]
    scale = detect_scale(scores)

    # ① 多口径重算
    def views(field_fn):
        out = {}
        for subset_name, flt in (("all", lambda r: True), ("status_ok", lambda r: r["ok"])):
            pairs = [(r["st"], field_fn(r)) for r in rows if flt(r) and field_fn(r) is not None]
            out[f"{subset_name}/micro"] = _mean([v for _, v in pairs])
            out[f"{subset_name}/macro"] = _macro(pairs)
        return out

    hyps = {}
    if scores:
        if scale in ("binary", "unit"):
            for k, v in views(lambda r: r["score"]).items():
                hyps[f"score_mean@{k}"] = v
        elif scale == "judge5":
            for k, v in views(lambda r: None if r["score"] is None else r["score"] / 5.0).items():
                hyps[f"score/5@{k}"] = v
            for k, v in views(lambda r: None if r["score"] is None
                              else float(r["score"] >= args.judge_pass)).items():
                hyps[f"score>={args.judge_pass}@{k}"] = v
    if any(r["has_correct"] for r in rows):
        for k, v in views(lambda r: float(r["correct"]) if r["has_correct"] else None).items():
            hyps[f"correct@{k}"] = v

    matched = {k: v for k, v in hyps.items()
               if acc is not None and v is not None and abs(v - acc) <= ACC_TOL}
    score_hit = next((k for k in matched if k.startswith("score")), None)
    correct_hit = next((k for k in matched if k.startswith("correct")), None)

    # ② 逐条方向一致率（score 与 correct 都在时）
    both = [r for r in rows if r["score"] is not None and r["has_correct"]]
    agree = None
    if both and scale in ("binary", "unit", "judge5"):
        agree = _mean([float(score_pass(r["score"], scale, args.judge_pass) == r["correct"])
                       for r in both])

    # ③ 锚点：输出==GT 的样本必然是 pass
    anchors = [r for r in rows if r["anchor"]]

    def anchor_pass_rate(field):
        if len(anchors) < ANCHOR_MIN:
            return None
        if field == "score":
            vals = [score_pass(r["score"], scale, args.judge_pass)
                    for r in anchors if r["score"] is not None]
        else:
            vals = [r["correct"] for r in anchors if r["has_correct"]]
        vals = [v for v in vals if v is not None]
        return _mean([float(v) for v in vals]) if len(vals) >= ANCHOR_MIN else None

    apr = {"score": anchor_pass_rate("score"), "correct": anchor_pass_rate("correct")}

    warnings = []
    authority, matched_by = None, None
    for field, hit in (("score", score_hit), ("correct", correct_hit)):
        if not hit:
            continue
        if apr[field] is not None and apr[field] < ANCHOR_PASS_MIN:
            warnings.append(f"{field} 均值对齐({hit})但锚点判 pass 率仅 {apr[field]:.2f}，方向疑似相反，弃用")
            continue
        authority, matched_by = field, hit
        break

    if authority and agree is not None and agree < 0.5:
        warnings.append(f"score 与 correct 逐条一致率 {agree:.2f}（<0.5，方向相反），已按锚点/口径选 {authority}，请人审")

    # 巧合对齐：acc≈0.5 时字段反过来也对得上，且没有锚点/交叉字段能裁决
    if authority and acc is not None and abs(acc - 0.5) <= ACC_TOL \
            and apr[authority] is None and agree is None:
        warnings.append("accuracy≈0.5：字段取反后均值同样对齐，且无锚点/交叉字段可裁决方向（ambiguous）")

    if authority is None and not is_asr:
        warnings.append("各口径下 score / correct 均未对齐 metrics.accuracy，或方向校验失败，跳过 bad/pass 选取（管理员审）")

    return {
        "bkey": bkey, "accuracy": acc, "is_asr": is_asr, "scale": scale,
        "n_samples": len(samples),
        "authority": authority, "matched_by": matched_by,
        "hypotheses": {k: (round(v, 4) if v is not None else None) for k, v in hyps.items()},
        "agree_score_vs_correct": round(agree, 4) if agree is not None else None,
        "n_anchors": len(anchors),
        "anchor_pass_rate": {k: (round(v, 4) if v is not None else None) for k, v in apr.items()},
        "warnings": warnings,
    }


# ─────────────────────────── 单条判定 + 失败签名 ───────────────────────────

RULES = {}   # bkey 通配 → 规则；由 --rules 加载


def match_rule(bkey):
    for pat, r in RULES.items():
        if fnmatch.fnmatch(bkey, pat):
            return r
    return None


def apply_rule(aud, rule):
    """按任务定义判对错，绕过 accuracy 对齐（FPR / TOR 这类指标本来就没有 accuracy）。"""
    aud["rule"] = rule
    aud["authority"] = f"rule:{rule['type']}"
    aud["matched_by"] = "rules.json"
    aud["warnings"] = [w for w in aud["warnings"] if "跳过" not in w and "未对齐" not in w]


def rule_verdict(s, rule):
    out = sample_output(s)
    if rule["type"] == "silent_is_pass":
        # 拒识 / 长暂停：不该说话。输出为空 = 对；有输出 = 抢话/误响应。
        # 若输出是时间轴 JSON，用 speak_field 指定"是否发声"的字段
        f = rule.get("speak_field")
        spoke = as_bool(s.get(f)) if f and s.get(f) is not None else bool(out)
        return ("bad", 1.0) if spoke else ("pass", 0.0)
    if rule["type"] == "field":
        v = as_float(s.get(rule["field"]))
        if v is None:
            return None, None
        op, th = rule.get("pass_if", ">="), float(rule.get("value", 1))
        ok = {">=": v >= th, ">": v > th, "<=": v <= th, "<": v < th, "==": v == th}[op]
        return ("pass", 0.0) if ok else ("bad", 1.0)
    return None, None


def verdict_of(s, aud, args, mer=None):
    """→ (verdict, severity)；verdict ∈ pass / bad / empty / None"""
    if aud.get("rule"):
        return rule_verdict(s, aud["rule"])
    if not sample_output(s):
        return "empty", 1.0
    sc = as_float(s.get("score"))
    if aud["is_asr"]:
        if mer is None:
            return None, None
        if mer >= args.asr_bad:
            return "bad", min(mer, 100.0) / 100.0
        if mer <= args.asr_pass:
            return "pass", 0.0
        return None, None
    if aud["authority"] == "score":
        if sc is None:
            return None, None
        p = score_pass(sc, aud["scale"], args.judge_pass)
        if p is None:
            return None, None
        return ("pass", 0.0) if p else ("bad", severity_of_score(sc, aud["scale"], args.judge_pass))
    if aud["authority"] == "correct":
        if s.get("correct") is None:
            return None, None
        if as_bool(s.get("correct")):
            return "pass", 0.0
        sev = severity_of_score(sc, aud["scale"], args.judge_pass) if sc is not None else 1.0
        return "bad", sev
    return None, None


CJK = re.compile(r"[\u4e00-\u9fff]")


def cjk_ratio(t):
    t = re.sub(r"\s+", "", t or "")
    return len(CJK.findall(t)) / len(t) if t else 0.0


def is_loop(t):
    t = re.sub(r"\s+", "", t or "")
    if len(t) < 20:
        return False
    grams = [t[i:i + 4] for i in range(len(t) - 3)]
    return len(set(grams)) / len(grams) < 0.3


def signature(out, gt, lang, sev):
    lo, lg = len(norm_lang(out, lang)), len(norm_lang(gt, lang))
    if not lg:
        lb = "no_gt"
    elif lo < 0.5 * lg:
        lb = "short"
    elif lo > 2.0 * lg:
        lb = "long"
    else:
        lb = "len_ok"
    cr = cjk_ratio(out)
    lang_mis = (lang == "zh" and len(out) >= 4 and cr < 0.2) or (lang == "en" and cr > 0.5)
    sb = "sev_hi" if sev >= 0.75 else ("sev_mid" if sev >= 0.4 else "sev_lo")
    return (lb, "loop" if is_loop(out) else "-", "lang_mis" if lang_mis else "-", sb)


def char_grams(t, n=3):
    t = re.sub(r"\s+", " ", (t or "").lower())[:600]
    if len(t) < n:
        return {t} if t else set()
    return {t[i:i + n] for i in range(len(t) - n + 1)}


def jaccard(a, b):
    if not a and not b:
        return 1.0
    u = len(a | b)
    return len(a & b) / u if u else 0.0


# ─────────────────────────── 配额分配 + 层内 MMR ───────────────────────────

def allocate(counts, budget, mode, rng):
    keys = sorted(k for k, c in counts.items() if c > 0)
    if not keys or budget <= 0:
        return {}
    w = {k: {"prop": counts[k], "sqrt": math.sqrt(counts[k]), "uniform": 1.0}[mode] for k in keys}
    if len(keys) > budget:                    # 层比名额多：按权重无放回抽层
        pool, chosen = keys[:], []
        for _ in range(budget):
            tot = sum(w[k] for k in pool)
            r, acc = rng.random() * tot, 0.0
            for k in pool:
                acc += w[k]
                if acc >= r:
                    chosen.append(k)
                    pool.remove(k)
                    break
        return {k: 1 for k in chosen}
    alloc = {k: 1 for k in keys}              # 保底覆盖
    rem = budget - len(keys)
    while rem > 0:                            # D'Hondt 式按权重补齐，封顶于层容量
        open_ = [k for k in keys if alloc[k] < counts[k]]
        if not open_:
            break
        k = max(open_, key=lambda x: (w[x] / (alloc[x] + 1), x))
        alloc[k] += 1
        rem -= 1
    return alloc


def mmr_pick(cands, k, picked_global, lam, dup_thr, rng):
    """cands: [{sev, grams, sig, ...}]；与 picked_global（跨层已选）一起去冗余。"""
    pool = cands[:]
    rng.shuffle(pool)                         # 并列时随机，而不是文件顺序

    def sim(a, b):
        sig_eq = sum(x == y for x, y in zip(a["sig"], b["sig"])) / len(a["sig"])
        return 0.6 * jaccard(a["grams"], b["grams"]) + 0.4 * sig_eq

    max_sim = {id(c): 0.0 for c in pool}
    max_txt = {id(c): 0.0 for c in pool}
    for p in picked_global:
        for c in pool:
            max_sim[id(c)] = max(max_sim[id(c)], sim(c, p))
            max_txt[id(c)] = max(max_txt[id(c)], jaccard(c["grams"], p["grams"]))

    out = []
    while pool and len(out) < k:
        best, best_v = None, -1e9
        for c in pool:
            if dup_thr is not None and max_txt[id(c)] >= dup_thr:
                continue
            v = lam * c["sev"] - (1 - lam) * max_sim[id(c)]
            if v > best_v:
                best, best_v = c, v
        if best is None:
            break
        best["max_sim"] = round(max_sim[id(best)], 3)
        out.append(best)
        pool.remove(best)
        for c in pool:
            max_sim[id(c)] = max(max_sim[id(c)], sim(c, best))
            max_txt[id(c)] = max(max_txt[id(c)], jaccard(c["grams"], best["grams"]))
    return out


# ─────────────────────────── 回归对比：baseline 逐条判定 ───────────────────────────

def baseline_verdicts(base, bkey, args):
    """返回 (bare_id → verdict, baseline audit)；baseline 缺该 bkey 时返回 (None, None)。"""
    mp, lp = f"{base}/_metrics/{bkey}.json", f"{base}/_ledgers/{bkey}"
    if not (os.path.isfile(mp) and os.path.isdir(lp)):
        return None, None
    with open(mp) as fh:
        doc = json.load(fh)
    samples = doc.get("samples", [])
    led = load_ledger(base, bkey)
    aud = profile_bkey(bkey, doc, samples, led, args)
    if match_rule(bkey):
        apply_rule(aud, match_rule(bkey))
    out = {}
    for s in samples:
        bare = resolve_bare_id(s["sample_id"], led, bkey)
        if not bare:
            continue
        rec = led[bare]
        mer = None
        if aud["is_asr"] and sample_output(s) and ledger_gt(rec):
            mer = per_case_mer(ledger_gt(rec), sample_output(s), ledger_lang(rec))
        out[bare] = verdict_of(s, aud, args, mer)[0]
    return out, aud


# ─────────────────────────── 主流程 ───────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--top-n", type=int, default=10, help="每 bkey 每类抽样条数")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--alloc", choices=["prop", "sqrt", "uniform"], default="sqrt")
    ap.add_argument("--lam", type=float, default=0.5, help="MMR 中严重度权重（1=只看严重度，0=只看多样性）")
    ap.add_argument("--dup-thr", type=float, default=None,
                    help="输出文本 Jaccard ≥ 此值视为近重复并硬跳过（默认关闭：音频任务里输出相同≠case 相同，"
                         "如选择题都答 A；只保留 MMR 软惩罚）")
    ap.add_argument("--judge-pass", type=float, default=4.0, help="judge 0-5 型 pass 阈值")
    ap.add_argument("--asr-bad", type=float, default=30.0)
    ap.add_argument("--asr-pass", type=float, default=5.0)
    ap.add_argument("--exclude-dirs", default="")
    ap.add_argument("--bkeys", default="")
    ap.add_argument("--classes", default="bad,pass,empty")
    ap.add_argument("--no-empty", action="store_true")
    ap.add_argument("--rules", default="",
                    help="按任务定义判对错的规则 JSON：{bkey通配: {type: silent_is_pass | field, ...}}，"
                         "用于拒识/长暂停等非 accuracy 指标的 bkey")
    ap.add_argument("--baseline", default="",
                    help="旧 ckpt 的 raw_out；给定后 bad 类只保留 baseline 判 pass 的翻转 case")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    if args.rules:
        RULES.update(json.load(open(args.rules)))
    want = {c.strip() for c in args.classes.split(",") if c.strip()}
    if args.no_empty:
        want.discard("empty")
    only_bkeys = {b.strip() for b in args.bkeys.split(",") if b.strip()}

    excluded = set()
    for d in filter(None, args.exclude_dirs.split(":")):
        if os.path.isdir(d):
            for root, _, files in os.walk(d):
                if "meta.json" in files:
                    excluded.add(os.path.basename(root))
    print(f"增量排除已有 case：{len(excluded)} 条")

    plan, audit, stats = [], [], Counter()
    for f in sorted(os.listdir(f"{args.base}/_metrics")):
        bkey = f[:-5]
        if not f.endswith(".json") or not os.path.isdir(f"{args.base}/_ledgers/{bkey}"):
            continue
        if only_bkeys and bkey not in only_bkeys:
            continue
        with open(f"{args.base}/_metrics/{f}") as fh:
            doc = json.load(fh)
        samples = doc.get("samples", [])
        if not samples:
            continue
        led = load_ledger(args.base, bkey)
        aud = profile_bkey(bkey, doc, samples, led, args)
        if match_rule(bkey):
            apply_rule(aud, match_rule(bkey))
        audit.append(aud)
        if aud["authority"] is None and not aud["is_asr"]:
            stats["skipped_bkeys"] += 1
            continue

        bmap = None
        if args.baseline:
            bmap, baud = baseline_verdicts(args.baseline, bkey, args)
            aud["baseline"] = ({"authority": baud["authority"], "warnings": baud["warnings"]}
                               if baud else "baseline 无此 bkey，未做翻转过滤")
            if baud and baud["authority"] is None and not baud["is_asr"]:
                aud["warnings"].append("baseline 该 bkey 权威字段未通过校验，翻转判断不可靠，已不做翻转过滤")
                bmap = None

        # —— 建池（排除已有 case 在此处，先于抽样）——
        pools = defaultdict(list)
        seen = set()
        for s in samples:
            bare = resolve_bare_id(s["sample_id"], led, bkey)
            if not bare or bare in seen or bare in excluded:
                continue
            seen.add(bare)
            rec = led[bare]
            lang, gt, out = ledger_lang(rec), ledger_gt(rec), sample_output(s)
            mer = None
            if aud["is_asr"] and out:
                if not gt:
                    continue
                mer = per_case_mer(gt, out, lang)
            v, sev = verdict_of(s, aud, args, mer)
            if v not in want:
                continue
            if v == "bad" and bmap is not None and bmap.get(bare) != "pass":
                stats["bad_not_flipped"] += 1
                continue
            sig = signature(out, gt, lang, sev or 0.0) if v == "bad" else ("-",) * 4
            pools[v].append({"s": s, "bare": bare, "rec": rec, "mer": mer, "sev": sev or 0.0,
                             "sig": sig, "grams": char_grams(out),
                             "st": ledger_subtask(rec) or "∅"})

        coverage = {}
        for v in ("bad", "pass", "empty"):
            pool = pools.get(v, [])
            if not pool:
                continue
            # —— 分层：subtask；只有一层时，bad 退化为按失败签名分层 ——
            strata_key = (lambda c: c["st"])
            if v == "bad" and len({c["st"] for c in pool}) == 1:
                strata_key = (lambda c: "|".join(x for x in c["sig"][:3] if x != "-") or "plain")
            strata = defaultdict(list)
            for c in pool:
                c["stratum"] = strata_key(c)
                strata[c["stratum"]].append(c)
            alloc = allocate({k: len(x) for k, x in strata.items()}, args.top_n, args.alloc, rng)

            picked = []
            for sk in sorted(alloc):
                if v == "bad":
                    got = mmr_pick(strata[sk], alloc[sk], picked, args.lam, args.dup_thr, rng)
                else:
                    cs = strata[sk][:]
                    rng.shuffle(cs)
                    got = cs[:alloc[sk]]
                picked.extend(got)
            if len(picked) < min(args.top_n, len(pool)):
                stats[f"shortfall_{v}"] += min(args.top_n, len(pool)) - len(picked)

            coverage[v] = {
                "pool_by_stratum": dict(Counter(c["stratum"] for c in pool)),
                "picked_by_stratum": dict(Counter(c["stratum"] for c in picked)),
            }
            if v == "bad":
                coverage[v]["pool_signature"] = dict(Counter("/".join(c["sig"]) for c in pool).most_common(12))
                coverage[v]["picked_signature"] = dict(Counter("/".join(c["sig"]) for c in picked))

            for c in picked:
                s, rec = c["s"], c["rec"]
                assets = (rec.get("media") or {}).get("assets") or []
                row = {
                    "class": {"bad": "judge_wrong", "pass": "pass", "empty": "no_speech"}[v],
                    "bkey": bkey, "sample_id": s["sample_id"], "case_id": c["bare"],
                    "gt": ledger_gt(rec), "output": sample_output(s),
                    "subtask": ledger_subtask(rec), "language": ledger_lang(rec),
                    "audio_uri": assets[0].get("uri", "") if assets else "",
                    "question": next((x.get("text", "") for x in rec["messages"][0]["content"]
                                      if x.get("type") == "text"), ""),
                    "mer": round(c["mer"], 2) if c["mer"] is not None else None,
                    "score": s.get("score"), "correct": s.get("correct"),
                    "scoring_status": s.get("scoring_status"),
                    "authority": aud["authority"], "scale": aud["scale"],
                    "stratum": c["stratum"], "severity": round(c["sev"], 3),
                    "signature": "/".join(c["sig"]), "max_sim": c.get("max_sim"),
                    "judge_reason": next((str(s.get(k)) for k in REASON_KEYS if s.get(k)), None),
                    "baseline_verdict": (bmap or {}).get(c["bare"]) if bmap is not None else None,
                    "note": f"authority={aud['authority']}({aud['matched_by']}) scale={aud['scale']} "
                            f"stratum={c['stratum']}",
                }
                if not row["audio_uri"]:
                    stats["no_audio_uri"] += 1
                    row["note"] += "; audio_uri 缺失, events 回退"
                plan.append(row)
                stats[v] += 1
        aud["coverage"] = coverage

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w") as fo:
        json.dump({"base": args.base, "seed": args.seed, "top_n": args.top_n,
                   "alloc": args.alloc, "lam": args.lam, "baseline": args.baseline or None,
                   "stats": dict(stats), "audit": audit, "plan": plan},
                  fo, ensure_ascii=False, indent=1)

    print(f"\nplan → {args.out}  共 {len(plan)} 条  统计={dict(stats)}")
    print("\n── audit ──")
    for a in audit:
        flag = "⚠" if a["warnings"] else " "
        print(f" {flag} {a['bkey']}: acc={a['accuracy']} scale={a['scale']} "
              f"authority={a['authority']} via {a['matched_by']} "
              f"anchors={a['n_anchors']} agree={a['agree_score_vs_correct']}")
        for w in a["warnings"]:
            print(f"      └ {w}")
        bad_cov = a.get("coverage", {}).get("bad")
        if bad_cov:
            print(f"      bad 池分层 {bad_cov['pool_by_stratum']} → 选中 {bad_cov['picked_by_stratum']}")


if __name__ == "__main__":
    main()
