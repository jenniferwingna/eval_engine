#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""triage_judge.py — badcase 判因：规则分诊 + 模型盲判 + 按根因精选。

为什么需要这一步：
  select_samples.py 选出的是"打分低"的样本，不是"模型错"的样本。一条低分 case 可能是：
    模型真错 / 评分器误判（答对了没解析出来）/ GT 本身错 / 数据坏（音频截断、prompt 丢失）/
    输出形态特殊（时间轴 JSON）/ 任务本就该沉默。
  分数只给出"低"这一个信号，脚本区分不了这些原因；不区分的后果是：
    badcase 包里混进评测侧的 bug，被当成模型问题去分析。

三层处理：
  ① 规则分诊（确定性，零成本）：评分未完成、GT 缺失/结构化、非文本输出、
     选择题答案抽取、ASR 复读/续写/语种错配、该沉默的 bkey 空输出。
  ② 模型盲判（规则判不了的剩余部分）：judge 不看原分数，独立判断"输出对不对"、
     "GT 是否合理"、"是否需要听音频才能判"，并写一个 ≤15 字的失败描述（开放编码）。
     再由脚本对比原判定与盲判结果得出根因。盲判是为了避免 judge 被原分数锚定。
  ③ 精选：模型侧根因（model_error）按失败描述聚类分层抽取 --final-n 条；
     评测侧根因（scorer_false_negative / false_pass / gt_suspect / judge_disagree …）
     全部单独输出到 eval_issues.json，不进模型 badcase 包。

用法：
  # 候选池（最终条数的 3~5 倍；bad 池不大时直接设大值做全量判因）
  python3 select_samples.py --base <raw_out> --out cand.json --top-n 50
  # 判因 + 精选
  python3 triage_judge.py --plan cand.json --out plan.json \\
      --api-base http://<host>:<port>/v1 --model <judge 模型名> \\
      --evaluated-model <被测模型名> --final-n 10 --workers 16
  # 只看 prompt 不调模型
  python3 triage_judge.py --plan cand.json --out plan.json --dry-run
  # 人工校验后算一致率
  python3 triage_judge.py --calib human_check.jsonl

产物（与 --out 同目录）：
  plan.json          精选后的组包计划（字段兼容 assemble_pkg.py，每行新增 triage 字段）
  eval_issues.json   评测侧问题全量清单（给评测工程修评分器 / GT 用）
  triage_all.json    候选池全部 case 的判因明细 + 每 bkey 根因分布
  human_check.jsonl  分层抽取的人工校验单（human_* 字段待填）
"""
import argparse
import concurrent.futures as cf
import hashlib
import json
import math
import os
import random
import re
import sys
import time
import urllib.request
from collections import Counter, defaultdict

PROMPT_VERSION = "triage-v1"

MODEL_SIDE = {"model_error", "needs_audio", "unjudgeable_keep", "unverified"}
EVAL_SIDE = {"scorer_false_negative", "false_pass", "gt_suspect", "judge_disagree",
             "scorer_error", "gt_missing", "expected_silence"}

# ─────────────────────────── 通用小工具 ───────────────────────────

CJK = re.compile(r"[一-鿿]")


def norm(t):
    t = re.sub(r"\s+", "", str(t or "")).lower()
    return re.sub(r"[，。！？、；：“”‘’《》（）…—,.!?;:()<>\"'\-]", "", t)


def is_loop(t):
    t = re.sub(r"\s+", "", t or "")
    if len(t) < 20:
        return False
    g = [t[i:i + 4] for i in range(len(t) - 3)]
    return len(set(g)) / len(g) < 0.3


def cjk_ratio(t):
    t = re.sub(r"\s+", "", t or "")
    return len(CJK.findall(t)) / len(t) if t else 0.0


def grams(t, n=3):
    t = norm(t)
    return {t[i:i + n] for i in range(max(1, len(t) - n + 1))} if t else set()


def jaccard(a, b):
    u = len(a | b)
    return len(a & b) / u if u else 0.0


def looks_structured(x):
    if isinstance(x, (list, dict)):
        return True
    x = str(x or "").strip()
    if x[:1] in "[{":
        try:
            json.loads(x)
            return True
        except Exception:
            return False
    return False


CN_DIG = {"零": 0, "〇": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5,
          "六": 6, "七": 7, "八": 8, "九": 9}
CN_UNIT = {"十": 10, "百": 100, "千": 1000}
CN_RUN = re.compile(r"[零〇一二两三四五六七八九十百千万]+")


def _cn_run_to_digits(run):
    if not any(c in run for c in "十百千万"):           # 一二三 → 123（电话号、编号）
        return "".join(str(CN_DIG[c]) for c in run)
    total = section = num = 0
    for c in run:
        if c in CN_DIG:
            num = CN_DIG[c]
        elif c in CN_UNIT:
            section += (num or 1) * CN_UNIT[c]
            num = 0
        elif c == "万":
            total += (section + num) * 10000
            section = num = 0
    return str(total + section + num)


def cn_textnorm(t):
    """中文数字 → 阿拉伯数字（二十六→26、三点→3点），两边同样处理后再比。"""
    return CN_RUN.sub(lambda m: _cn_run_to_digits(m.group(0)), t or "")


def _edit(a, b):
    prev = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        cur = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] != b[j - 1]))
        prev = cur
    return prev[-1]


MCQ_GT = re.compile(r"^\(?([A-Ja-j])\)?[.、:：]?$")
MCQ_OUT = [
    re.compile(r"^\(?([A-J])\)?(?:[.。、:：\s，,]|$)"),                       # 开头就是选项
    re.compile(r"(?:答案|选项|选择|answer is|answer:)\s*(?:是|为)?\s*[:：]?\s*\(?([A-J])\)?", re.I),
]


def mcq_choice(out):
    o = (out or "").strip()
    for p in MCQ_OUT:
        m = p.search(o)
        if m:
            return m.group(1).upper()
    return None


# ─────────────────────────── ① 规则分诊 ───────────────────────────

def rule_triage(row, silence_ok):
    """确定性分诊。返回 triage dict 或 None（交给模型）。"""
    cls, bkey = row["class"], row["bkey"]
    out, gt = row.get("output") or "", row.get("gt")
    st = str(row.get("scoring_status") or "")

    def T(rc, fm, rule, needs_audio=False):
        return {"root_cause": rc, "failure_mode": fm, "method": f"rule:{rule}",
                "needs_audio": needs_audio, "confidence": 1.0 if not needs_audio else 0.5}

    if str(row.get("authority") or "").startswith("rule:silent"):
        if cls == "pass":
            return T("pass_confirmed", "保持沉默", "silent_rule")
        n = len(norm(out))
        if n <= 4:
            return T("model_error", "附和式插话（短应答）", "silent_rule")
        if row.get("gt") and norm(out) and norm(out) in norm(str(row["gt"])):
            return T("model_error", "复述用户话语", "silent_rule")
        return T("model_error", "完整抢答（误判为轮到自己）", "silent_rule")

    if cls == "no_speech":
        if bkey in silence_ok:
            return T("expected_silence", "该任务沉默可能是正确行为", "silence_ok")
        return T("needs_audio", "空输出：需查 events 区分链路丢包与模型未回应", "empty", True)

    if st and re.search(r"fail|error|skip|timeout|invalid", st, re.I):
        return T("scorer_error", f"评分未完成（{st}）", "scoring_status")
    if gt is None or (isinstance(gt, str) and not gt.strip()):
        return T("gt_missing", "GT 为空，无法判定", "gt_empty")
    if looks_structured(gt):
        return T("gt_missing", "GT 为结构化数据，需专用评分器", "gt_structured")
    if looks_structured(out):
        # 如 fdb backchannel 的 chunk 时间轴 JSON：文本 judge 看不懂，信任原评分器
        return T("unjudgeable_keep", "非文本输出，保留原评分判定", "out_structured")

    # 选择题：答案抽取可确定性完成
    m = MCQ_GT.match(str(gt).strip())
    if m:
        g, o = m.group(1).upper(), mcq_choice(out)
        if o is not None:
            if cls == "judge_wrong" and o == g:
                return T("scorer_false_negative", f"输出含正确选项 {g} 但被判错（解析失败）", "mcq_extract")
            if cls == "pass" and o != g:
                return T("false_pass", f"抽取选项 {o}≠GT {g} 却判对", "mcq_extract")
            if cls == "judge_wrong":
                t = T("model_error", "选错选项", "mcq_extract")
                t["evidence"], t["mcq_pick"] = f"{o}→应为{g}", o
                return t
            return T("pass_confirmed", "选项正确", "mcq_extract")

    # ASR 形态（MER 字段存在即视为 ASR 行）
    if row.get("mer") is not None and cls == "judge_wrong":
        lang = row.get("language") or "zh"
        if is_loop(out):
            return T("model_error", "复读循环", "asr_loop")
        if (lang == "zh" and len(out) >= 4 and cjk_ratio(out) < 0.2) or (lang == "en" and cjk_ratio(out) > 0.5):
            return T("model_error", "输出语种与音频不符", "asr_lang")
        ng, no = norm(gt), norm(out)
        if lang != "en":
            rg, ro = norm(cn_textnorm(gt)), norm(cn_textnorm(out))
            if rg and _edit(ro, rg) / len(rg) * 100 <= 5.0:
                return T("scorer_false_negative", "数字写法差异（二十六↔26），TextNorm 未覆盖",
                         "asr_textnorm")
        if ng and ng in no and len(no) > 1.3 * len(ng):
            return T("model_error", "转写后续写/闲聊", "asr_continue")
    if row.get("mer") is not None and cls == "pass":
        return T("pass_confirmed", "MER 低于阈值", "asr_pass")
    return None


# ─────────────────────────── ② 模型盲判 ───────────────────────────

SYS_QA = """你是语音/多模态模型评测的复核员。你会看到一道题、参考答案（GT）和被测模型的输出。
你看不到音频，也看不到原评分结果。请独立判断，只输出一个 JSON，不要输出别的内容。

判断要点：
1. 只看语义，不看格式：输出"答案是B，因为……"与 GT "B" 视为一致；数字写法、繁简、标点、语气词差异不算错。
2. 若题目或 GT 显然依赖音频里的信息、而你仅凭文字无法判断输出对错，verdict 填 "cannot_judge" 且 needs_audio=true。不要猜。
3. gt_plausible：GT 本身是否与题目自洽。只有在明显矛盾（答非所问、选项不存在、事实性明显错误）时才填 false，拿不准填 null。
4. failure_mode：若输出有错，用不超过 15 个字描述"错在哪"，描述行为而不是猜原因。
   好的例子："答非所问，复述了问题"、"拒答"、"数值算错"、"只回答了一半"、"把方言词听成近音词"
   不好的例子："模型能力不足"、"错误"、"理解偏差"
5. evidence：从输出里摘一个不超过 20 字的片段作为依据。

输出格式：
{"verdict": "correct|partially_correct|incorrect|cannot_judge", "gt_plausible": true|false|null,
 "needs_audio": true|false, "failure_mode": "...", "evidence": "..."}"""

SYS_ASR = """你是语音识别评测的复核员。你会看到参考转写（REF）和模型转写（HYP），以及按字/词算出的错误率。
你听不到音频。请判断两者差异的性质，只输出一个 JSON。

- "equivalent"：差异全部属于书写规范化问题，不算识别错误。例如：
  REF「调到二十六度」HYP「调到26度」；REF「後天」HYP「后天」；只差标点、空格、"嗯/啊"等语气词。
- "minor_error"：有少量真实识别错误，但主体意思保留。例如：REF「明天上午九点」HYP「明天上午十点」。
- "major_error"：大面积错误、漏转、多转、改写了意思。
- gt_suspect：REF 本身看起来有问题（明显错字、与 HYP 的通顺版本相比像是标注错误）时填 true，拿不准填 false。
- failure_mode：不超过 15 字，描述错误形态，如"数字识别错"、"人名近音替换"、"句尾漏转"、"英文词听成中文"。
- evidence：用"REF片段→HYP片段"的形式给一处最典型的差异。

输出格式：
{"verdict": "equivalent|minor_error|major_error", "gt_suspect": true|false, "failure_mode": "...", "evidence": "..."}"""


def build_messages(row):
    if row.get("mer") is not None:
        user = (f"REF：{row.get('gt','')}\nHYP：{row.get('output','')}\n"
                f"按字/词算的错误率：{row['mer']}%")
        return "asr", [{"role": "system", "content": SYS_ASR}, {"role": "user", "content": user}]
    q = (row.get("question") or "").strip() or "（题目文字为空，题目可能完全在音频里）"
    user = (f"任务：{row['bkey']}" + (f" / {row['subtask']}" if row.get("subtask") else "") +
            f"\n题目：{q[:1500]}\n参考答案（GT）：{str(row.get('gt',''))[:1500]}\n"
            f"模型输出：{str(row.get('output',''))[:2000]}")
    return "qa", [{"role": "system", "content": SYS_QA}, {"role": "user", "content": user}]


def call_judge(messages, args, cache):
    key = hashlib.sha1(json.dumps([args.model, PROMPT_VERSION, messages], ensure_ascii=False)
                       .encode()).hexdigest()
    if key in cache:
        return cache[key], True
    body = json.dumps({"model": args.model, "messages": messages, "temperature": 0,
                       "max_tokens": 400}).encode()
    headers = {"Content-Type": "application/json"}
    if os.environ.get(args.api_key_env):
        headers["Authorization"] = f"Bearer {os.environ[args.api_key_env]}"
    last = None
    for attempt in range(3):
        try:
            req = urllib.request.Request(args.api_base.rstrip("/") + "/chat/completions",
                                         data=body, headers=headers)
            with urllib.request.urlopen(req, timeout=args.timeout) as r:
                txt = json.loads(r.read())["choices"][0]["message"]["content"]
            m = re.search(r"\{.*\}", txt, re.S)
            res = json.loads(m.group(0)) if m else None
            if not isinstance(res, dict) or "verdict" not in res:
                raise ValueError(f"judge 输出无法解析：{txt[:200]}")
            cache[key] = res
            return res, False
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(1.5 * (attempt + 1))
    return {"verdict": "_error", "error": str(last)[:300]}, False


def combine(row, kind, j):
    """原判定 + 盲判 → 根因。"""
    cls, v = row["class"], j.get("verdict")
    fm = (j.get("failure_mode") or "").strip()[:30]
    base = {"method": f"judge:{kind}", "judge_raw": j, "failure_mode": fm,
            "needs_audio": bool(j.get("needs_audio")), "confidence": None}
    if v == "_error":
        return {**base, "root_cause": "needs_audio", "failure_mode": "judge 调用失败，需人工",
                "confidence": 0.0}
    if kind == "asr":
        if cls == "judge_wrong":
            if v == "equivalent":
                rc = "scorer_false_negative"
                base["failure_mode"] = "仅规范化差异（TextNorm 未覆盖）"
            elif j.get("gt_suspect"):
                rc = "gt_suspect"
            else:
                rc = "model_error"
        else:
            rc = "pass_confirmed" if v == "equivalent" else "false_pass"
        return {**base, "root_cause": rc}

    # qa
    orig_is_llm_judge = row.get("scale") in ("judge5", "unit")
    if v == "cannot_judge" or j.get("needs_audio"):
        return {**base, "root_cause": "needs_audio" if cls == "judge_wrong" else "pass_unverified",
                "needs_audio": True}
    if cls == "judge_wrong":
        if v == "correct":
            # 原评分若本身是 LLM judge，两个 judge 分歧不能断定谁对 → 人审
            rc = "judge_disagree" if orig_is_llm_judge else "scorer_false_negative"
        elif j.get("gt_plausible") is False:
            rc = "gt_suspect"
        else:
            rc = "model_error"
    else:
        if v == "incorrect":
            rc = "judge_disagree" if orig_is_llm_judge else "false_pass"
        else:
            rc = "pass_confirmed"
    return {**base, "root_cause": rc}


# ─────────────────────────── ③ 精选 ───────────────────────────

def cluster_modes(rows, thr=0.45):
    """按 failure_mode 文本贪心聚类（开放编码的粗归并，正式归类仍需人工轴心编码）。"""
    centers = []
    for r in rows:
        g = grams(r["triage"]["failure_mode"])
        for c in centers:
            if jaccard(g, c["g"]) >= thr:
                c["rows"].append(r)
                break
        else:
            centers.append({"g": g, "label": r["triage"]["failure_mode"] or "∅", "rows": [r]})
    return {c["label"]: c["rows"] for c in centers}


def allocate(counts, budget, rng):
    keys = sorted(k for k, c in counts.items() if c > 0)
    if not keys or budget <= 0:
        return {}
    w = {k: math.sqrt(counts[k]) for k in keys}
    if len(keys) > budget:
        keys = sorted(keys, key=lambda k: (-counts[k], rng.random()))[:budget]
        return {k: 1 for k in keys}
    alloc = {k: 1 for k in keys}
    rem = budget - len(keys)
    while rem > 0:
        open_ = [k for k in keys if alloc[k] < counts[k]]
        if not open_:
            break
        k = max(open_, key=lambda x: (w[x] / (alloc[x] + 1), x))
        alloc[k] += 1
        rem -= 1
    return alloc


def final_pick(rows, n, rng):
    """模型侧 badcase：先按失败描述聚类，再按 sqrt 配额抽；needs_audio 排在后面。"""
    strong = [r for r in rows if r["triage"]["root_cause"] == "model_error"]
    weak = [r for r in rows if r["triage"]["root_cause"] != "model_error"]
    picked = []
    if strong:
        groups = cluster_modes(strong)
        alloc = allocate({k: len(v) for k, v in groups.items()}, n, rng)
        for k in sorted(alloc):
            g = groups[k][:]
            rng.shuffle(g)
            for r in g[:alloc[k]]:
                r["triage"]["mode_cluster"] = k
                picked.append(r)
    if len(picked) < n and weak:
        # 未经判因的 case 沿用选取阶段的分层（subtask / 失败签名），保持覆盖面
        layers = defaultdict(list)
        for r in weak:
            layers[r.get("stratum") or r.get("subtask") or "∅"].append(r)
        alloc = allocate({k: len(v) for k, v in layers.items()}, n - len(picked), rng)
        for k in sorted(alloc):
            g = layers[k][:]
            rng.shuffle(g)
            picked += g[:alloc[k]]
    return picked


# ─────────────────────────── 人工校验一致率 ───────────────────────────

def calib(path):
    rows = [json.loads(l) for l in open(path) if l.strip()]
    done = [r for r in rows if r.get("human_root_cause")]
    if not done:
        print("human_check 里还没有填 human_root_cause")
        return
    by = defaultdict(lambda: [0, 0])
    for r in done:
        by[r["root_cause"]][1] += 1
        by[r["root_cause"]][0] += r["human_root_cause"] == r["root_cause"]
    tot = sum(a for a, _ in by.values()) / len(done)
    print(f"已标 {len(done)} 条，总一致率 {tot:.2f}")
    for k, (a, n) in sorted(by.items(), key=lambda x: -x[1][1]):
        flag = "  ⚠ 低于 0.8，该根因不要直接信 judge" if n >= 3 and a / n < 0.8 else ""
        print(f"  judge 判 {k:<24} {a}/{n} = {a / n:.2f}{flag}")
    conf = Counter((r["root_cause"], r["human_root_cause"]) for r in done if r["root_cause"] != r["human_root_cause"])
    if conf:
        print("  主要分歧（judge → 人）：")
        for (a, b), c in conf.most_common(8):
            print(f"    {a} → {b}: {c}")


# ─────────────────────────── 主流程 ───────────────────────────

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plan", help="select_samples.py 产出的候选池 plan")
    ap.add_argument("--out", help="精选后的 plan.json")
    ap.add_argument("--api-base", default="", help="OpenAI 兼容接口，如 http://host:8000/v1")
    ap.add_argument("--model", default="", help="judge 模型名")
    ap.add_argument("--api-key-env", default="JUDGE_API_KEY")
    ap.add_argument("--evaluated-model", default="", help="被测模型名，用于防止自己评自己")
    ap.add_argument("--allow-self-judge", action="store_true")
    ap.add_argument("--final-n", type=int, default=10, help="每 bkey 每类最终条数")
    ap.add_argument("--workers", type=int, default=16)
    ap.add_argument("--timeout", type=int, default=120)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--cache", default="", help="judge 结果缓存 jsonl（默认与 --out 同目录）")
    ap.add_argument("--silence-ok-bkeys", default="",
                    help="空输出可能是正确行为的 bkey（逗号分隔），如打断/拒识/附和类任务")
    ap.add_argument("--judge-pass", action="store_true",
                    help="对 pass 类也做盲判（查假阳性）；默认只判 bad")
    ap.add_argument("--human-n", type=int, default=40, help="人工校验单条数")
    ap.add_argument("--dry-run", action="store_true", help="只打印 prompt，不调模型")
    ap.add_argument("--no-judge", action="store_true",
                    help="不接 judge：只做规则分诊，其余标 unverified（仍进模型包，按选取分层抽）")
    ap.add_argument("--trust-scorer-bkeys", default="",
                    help="GT/输出本来就是结构化的 bkey（工具调用轨迹等，逗号分隔，支持通配）："
                         "不把结构化判为评测侧问题，信任原评分器")
    ap.add_argument("--llm-scored-bkeys", default="",
                    help="原评分本身就是 LLM judge 的 bkey（逗号分隔，支持通配如 vcb_*）："
                         "不再二次盲判，沿用原评分，原 judge 的理由（若有）作为失败描述")
    ap.add_argument("--calib", default="", help="填好的 human_check.jsonl → 算一致率后退出")
    args = ap.parse_args()

    if args.calib:
        calib(args.calib)
        return
    if not (args.plan and args.out):
        ap.error("--plan 与 --out 必填")
    if not (args.dry_run or args.no_judge) and not (args.api_base and args.model):
        ap.error("需要 --api-base 与 --model；不接 judge 请加 --no-judge")
    if (args.evaluated_model and args.model and not args.allow_self_judge and
            (args.evaluated_model.lower() in args.model.lower() or args.model.lower() in args.evaluated_model.lower())):
        sys.exit(f"judge 模型（{args.model}）与被测模型（{args.evaluated_model}）同源，"
                 "会偏袒自己的输出。换一个 judge，或确认后加 --allow-self-judge。")

    rng = random.Random(args.seed)
    plan_doc = json.load(open(args.plan))
    rows = plan_doc["plan"]
    silence_ok = {b.strip() for b in args.silence_ok_bkeys.split(",") if b.strip()}
    out_dir = os.path.dirname(os.path.abspath(args.out))
    os.makedirs(out_dir, exist_ok=True)
    cache_path = args.cache or os.path.join(out_dir, "judge_cache.jsonl")
    cache = {}
    if os.path.exists(cache_path):
        for l in open(cache_path):
            if l.strip():
                d = json.loads(l)
                cache[d["k"]] = d["v"]
    n_cache0 = len(cache)

    import fnmatch
    llm_pats = [p.strip() for p in args.llm_scored_bkeys.split(",") if p.strip()]
    trust_pats = [p.strip() for p in args.trust_scorer_bkeys.split(",") if p.strip()]
    STRUCT_RULES = {"rule:gt_structured", "rule:out_structured", "rule:gt_empty"}

    def unverified(r, why):
        reason = (r.get("judge_reason") or "").strip()
        return {"root_cause": "unverified" if r["class"] == "judge_wrong" else "pass_unverified",
                "failure_mode": reason[:30], "method": f"skip:{why}", "needs_audio": False,
                "confidence": None, "orig_judge_reason": reason[:500] or None}

    # ① 规则
    todo = []
    for r in rows:
        t = rule_triage(r, silence_ok)
        if any(fnmatch.fnmatch(r["bkey"], p) for p in trust_pats) and (t is None or t["method"] in STRUCT_RULES):
            r["triage"] = unverified(r, "trust_scorer")
        elif t is not None:
            r["triage"] = t
        elif any(fnmatch.fnmatch(r["bkey"], p) for p in llm_pats):
            r["triage"] = unverified(r, "llm_scored")
        elif args.no_judge:
            r["triage"] = unverified(r, "no_judge")
        elif r["class"] == "pass" and not args.judge_pass:
            r["triage"] = {"root_cause": "pass_unverified", "failure_mode": "", "method": "skip",
                           "needs_audio": False, "confidence": None}
        else:
            todo.append(r)
    m_ = Counter(r["triage"]["method"].split(":")[0] for r in rows if "triage" in r)
    print(f"候选 {len(rows)} 条：规则分诊 {m_.get('rule', 0)} 条，不判（沿用原评分）{m_.get('skip', 0)} 条，"
          f"交模型 {len(todo)} 条")

    # ② 模型
    if args.dry_run:
        for r in todo[:3]:
            kind, msgs = build_messages(r)
            print(f"\n──── [{kind}] {r['bkey']} / {r['case_id']} ────\n{msgs[1]['content']}")
        print(f"\n（dry-run：仅展示前 3 条 user 段；system 段见脚本 SYS_QA / SYS_ASR）")
        return

    def work(r):
        kind, msgs = build_messages(r)
        j, hit = call_judge(msgs, args, cache)
        return r, kind, j

    with cf.ThreadPoolExecutor(max(1, args.workers)) as ex:
        for i, (r, kind, j) in enumerate(ex.map(work, todo), 1):
            r["triage"] = combine(r, kind, j)
            if i % 50 == 0:
                print(f"  判因进度 {i}/{len(todo)}")
    with open(cache_path, "w") as fo:
        for k, v in cache.items():
            fo.write(json.dumps({"k": k, "v": v}, ensure_ascii=False) + "\n")
    for r in rows:
        r["triage"].update({"judge_model": args.model if r["triage"]["method"].startswith("judge") else None,
                            "prompt_version": PROMPT_VERSION})

    # ③ 精选 + 分流
    final, issues = [], []
    by = defaultdict(list)
    for r in rows:
        by[(r["bkey"], r["class"])].append(r)
    for (bkey, cls), rs in sorted(by.items()):
        if cls == "judge_wrong":
            final += final_pick([r for r in rs if r["triage"]["root_cause"] in MODEL_SIDE], args.final_n, rng)
        else:
            keep = [r for r in rs if r["triage"]["root_cause"] not in EVAL_SIDE]
            rng.shuffle(keep)
            # pass 优先已确认的
            keep.sort(key=lambda r: r["triage"]["root_cause"] != "pass_confirmed")
            final += keep[: args.final_n]
        issues += [r for r in rs if r["triage"]["root_cause"] in EVAL_SIDE]

    # 每 bkey 根因分布 + 是否为全量
    pool_total = {}
    for a in plan_doc.get("audit", []):
        cov = a.get("coverage", {}).get("bad")
        if cov:
            pool_total[a["bkey"]] = sum(cov["pool_by_stratum"].values())
    dist = {}
    for bkey in sorted({r["bkey"] for r in rows}):
        bad = [r for r in rows if r["bkey"] == bkey and r["class"] == "judge_wrong"]
        if not bad:
            continue
        c = Counter(r["triage"]["root_cause"] for r in bad)
        full = pool_total.get(bkey)
        dist[bkey] = {
            "judged_bad": len(bad), "bad_pool_total": full,
            "is_full_population": full is not None and len(bad) >= full,
            "root_cause": dict(c.most_common()),
            "eval_side_ratio": round(sum(v for k, v in c.items() if k in EVAL_SIDE) / len(bad), 3),
            # 选择题：错选字母若高度集中，是位置偏好（总选 A），只有跨 case 统计才看得出
            "mcq_wrong_pick": dict(Counter(r["triage"].get("mcq_pick") for r in bad
                                           if r["triage"].get("mcq_pick"))),
            "failure_modes": dict(Counter(r["triage"]["failure_mode"] for r in bad
                                          if r["triage"]["root_cause"] == "model_error").most_common(10)),
        }

    # 人工校验单：按根因分层
    groups = defaultdict(list)
    for r in rows:
        if r["triage"]["method"].startswith("judge") or r["triage"]["root_cause"] in EVAL_SIDE:
            groups[r["triage"]["root_cause"]].append(r)
    human = []
    alloc = allocate({k: len(v) for k, v in groups.items()}, args.human_n, rng)
    for k, m in alloc.items():
        g = groups[k][:]
        rng.shuffle(g)
        human += g[:m]

    plan_doc.update({"plan": final, "triage": {"prompt_version": PROMPT_VERSION, "judge_model": args.model,
                                               "by_bkey": dist}})
    json.dump(plan_doc, open(args.out, "w"), ensure_ascii=False, indent=1)
    json.dump(issues, open(os.path.join(out_dir, "eval_issues.json"), "w"), ensure_ascii=False, indent=1)
    json.dump({"by_bkey": dist, "rows": rows}, open(os.path.join(out_dir, "triage_all.json"), "w"),
              ensure_ascii=False, indent=1)
    with open(os.path.join(out_dir, "human_check.jsonl"), "w") as fo:
        for r in human:
            fo.write(json.dumps({
                "bkey": r["bkey"], "case_id": r["case_id"], "class": r["class"],
                "question": (r.get("question") or "")[:300], "gt": r.get("gt"), "output": r.get("output"),
                "score": r.get("score"), "mer": r.get("mer"), "audio_uri": r.get("audio_uri"),
                "root_cause": r["triage"]["root_cause"], "failure_mode": r["triage"]["failure_mode"],
                "human_root_cause": "", "human_failure_mode": "", "human_note": "",
            }, ensure_ascii=False) + "\n")

    print(f"\njudge 新调用 {len(cache) - n_cache0} 次（缓存命中其余）")
    print(f"精选 {len(final)} 条 → {args.out}")
    print(f"评测侧问题 {len(issues)} 条 → eval_issues.json")
    print(f"人工校验单 {len(human)} 条 → human_check.jsonl\n")
    print("── 每 bkey 的 badcase 根因分布 ──")
    for b, d in dist.items():
        scope = "全量" if d["is_full_population"] else f"候选 {d['judged_bad']}/{d['bad_pool_total'] or '?'}（非随机，比例仅参考）"
        print(f"  {b}  [{scope}]  评测侧占比 {d['eval_side_ratio']:.0%}  {d['root_cause']}")
        mp = d["mcq_wrong_pick"]
        if mp and sum(mp.values()) >= 10:
            top, cnt = max(mp.items(), key=lambda x: x[1])
            if cnt / sum(mp.values()) >= 0.5:
                print(f"      ⚠ 选错时 {cnt / sum(mp.values()):.0%} 选了 {top}：疑似位置偏好 {mp}")
        if d["failure_modes"]:
            print(f"      模型侧失败描述 top：{dict(list(d['failure_modes'].items())[:5])}")


if __name__ == "__main__":
    main()
