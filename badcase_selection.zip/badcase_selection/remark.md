# 适配备忘：在真实数据上接入 badcase-pipeline 前要补的东西

脚本是在模拟数据上验证的，很多地方用的是"推测的默认值"：bkey 名、字段名、哪些任务"沉默才算对"。这些在真实数据上不校准，脚本不一定会报错，但**会安静地筛错**。下面按"不补的后果"从重到轻排列。

先用这条命令看清每个 bkey 的真实样子，后面几乎每一项都要靠它：

```bash
# 看指标名和第一条样本的全部字段
python3 -c "import json,sys;d=json.load(open(sys.argv[1]));print('metrics:',json.dumps(d.get('metrics'),ensure_ascii=False));print(json.dumps(d['samples'][0],ensure_ascii=False,indent=1)[:1500])" <raw_out>/_metrics/<bkey>.json
# 看对应 ledger 第一条（GT、subtask、选项长什么样）
head -1 <raw_out>/_ledgers/<bkey>/ledger_v1.0.jsonl | python3 -m json.tool | head -60
```

---

## 一、必须补：不补会筛错

### 1. bkey 名：校准 `config/capabilities.json`

`ls <raw_out>/_metrics` 拿到真实 bkey 列表，逐个子能力核对 `bkeys` 里的通配是否能匹配上。以下 9 项是我推测的名字（配置里标了 `confirm: true`）：

座舱拒识（附和）、座舱拒识（接受）、座舱长暂停、SoulX-FDB-zh、FDB V2、FDB V3、Tau Voice、Tau-2、farnear；另外 Voice Bench 的子集分组也是推测的。

**不补的后果**：子能力匹配不到 bkey，"说话即错""信任原评分"这些规则不会生效，对应的 bkey 会按普通问答处理。

### 2. 每个子能力"对错怎么定"：逐项确认

这是最关键的一项。一个 case 算 badcase 还是 pass，脚本有四种判法：

| 判法 | 含义 | 配置写法 |
|---|---|---|
| 默认 | 用 score / correct，经三重校验确定方向 | 不写 |
| 说话即错 | 输出为空 = 对，模型说话了 = 错 | `"case_rule": "silent_is_pass"` |
| 按字段判 | 按某个 per-case 字段和阈值判 | `"case_rule": "field", "field": "...", "pass_if": "==", "value": 0` |
| 信任原评分 | 没有参考答案，或答案本来就是结构化的，不让分诊规则去碰 | `"trust_scorer": true` 或 bkey 列表 |

逐个子能力要确认的事：

| 子能力 | 要确认什么 | 不确认的后果 |
|---|---|---|
| SoulX-FDB-zh | 4 个子任务里，哪些任务模型沉默是正确行为（填 `--silence-ok-bkeys`）。backchannel 的 score 方向相反，引擎会自动处理，看 audit 确认即可 | 正确的沉默被当成"空输出、需查链路" |
| 座舱拒识（附和） | ① 是否"说话即错"；② 模型输出是纯文本，还是时间轴 JSON。如果是 JSON，"发声了"看哪个字段，填 `speak_field` | 输出是 JSON 时，脚本会把所有样本都当成"说话了"，全部判错 |
| 座舱拒识（接受） | **方向要确认。**名字叫"接受"，听起来像"应该回应"；但指标 FPR_speak 又像是"说话 = 误报"。我暂时按"说话即错"配置，很可能需要改 | 方向反了，badcase 和 pass 会整个对调 |
| 座舱长暂停 | TOR 在 per-case 层面怎么体现：是看输出是否为空，还是有类似 `takeover` 的字段？有字段就改用 `field` 判法 | 同上 |
| MMAU-mini | GT 是选项字母（"B"），还是选项文本（"Man speaking"）？ | 如果是文本，选择题抽取规则不生效：解析器误判查不出来，"总选 A"的位置偏好也检测不到，全部落成 `unverified` |
| VCB Bench | ① 哪些 bkey 是 LLM judge 打分的（`llm_scored`）；② metrics 里有没有 judge 理由字段 | 理由字段名不在脚本的识别列表里时，失败描述为空，只能按 subtask 粗分 |
| Voice Bench | 各子集的打分方式。据我了解：alpacaeval / commoneval / wildvoice / sd-qa 是 GPT 打分；mmsu / openbookqa 是选择题；ifeval 是规则；advbench 看拒答率。**以你们框架的实现为准** | 拒答类（advbench）的 GT 为空，不标 `trust_scorer` 的话会被误判成"GT 缺失" |
| FDB V2 | 模型还不能输出语音，这批是否接入了？没接入就不用管，配置会显示无数据 | — |
| IFEval | 已标 `trust_scorer`（没有参考答案）。确认 bkey 名，以及指标名是 strict 还是 loose | 不标的话会被误判成"GT 缺失" |
| FDB V3 / Tau Voice / Tau-2 / BFCL V3 | 已标 `trust_scorer`。确认 per-case 有没有 `score` / `correct` 字段，以及 Tau 系是不是按任务给 reward | **不标的话，badcase 会 100% 被分进评测侧问题**，模型包里一条都没有（模拟数据已验证） |
| ASR × 5 | 见下一条 | — |

### 3. ASR bkey 清单：改 `select_samples.py` 里的 `ASR_BKEYS`

脚本只对硬编码在 `ASR_BKEYS` 里的 bkey 算 per-case MER，现在只有 5 个：`wenet_net`、`wenet_meeting`、`librispeech`、`twinkstart_speechio_duplex`、`twinkstart_kespeech_duplex`。

需要做的：

- 把 **farnear**，以及 SpeechIO / KeSpeech 在本批的真实 bkey 名补进去；
- 确认 SpeechIO 采样子集（1000 条）是不是一个单独的 bkey。

**不补的后果**：漏掉的 ASR bkey 不算 MER，会被当成普通问答。复读、语种错配、数字写法差异（"二十六度"↔"26度"）这些规则全都不会生效。

### 4. metrics 里的字段名

用开头的命令看一条样本，确认这几个字段的真实名字：

| 脚本读的字段 | 用途 | 名字不一致时 |
|---|---|---|
| `raw_output`，其次 `parsed_answer` | 模型输出 | 所有样本都被当成空输出 |
| `score` / `correct` | 判对错 | 三重校验失败，bkey 被跳过 |
| `scoring_status` | 评分是否跑成功 | 评分失败的样本被当成模型错 |
| `judge_reason` / `reason` / `rationale` / `explanation` / `judge_output` / `critique` 之一 | 原 judge 的理由，用作失败描述 | 失败描述为空 |

名字不一致时，改 `select_samples.py` 的 `sample_output()` 或 `REASON_KEYS`。

### 5. 代码对接

- **`assemble_pkg.py` 是否透传 `triage` 字段**：组一次包，打开任意 `meta.json` 搜索 `triage`。没有的话，在写 meta 的地方加一行 `meta["triage"] = row.get("triage")`。不加的话，包里看不到根因。
- （可选）看板按根因筛：需要在 `sample_server.py` 的 facets 里加 `triage.root_cause`，不加也不影响使用。

---

## 二、每批跑之前要定的参数

| 参数 | 定什么 | 默认 |
|---|---|---|
| `--rules` | 用 `caps_to_rules.py` 从配置导出，不要手写 | — |
| `--llm-scored-bkeys` / `--trust-scorer-bkeys` | 同上，直接复制 `caps_to_rules.py` 打印的内容 | — |
| `--silence-ok-bkeys` | 走默认判法、但沉默可能是正确行为的 bkey。走"说话即错"规则的 bkey 不用填 | 空 |
| `--baseline` | 要做 ckpt 回归对比时，填旧 ckpt 的 raw_out | 不对比 |
| `--exclude-dirs` | **只填同一 ckpt** 已组过的包；跨 ckpt 填会让你看不到同一条 case 的前后对比 | 空 |
| `--top-n` | bad 池几百条以内时设成 300，即全量判因，比例才可信 | 10 |
| `--asr-bad` | 想看"车窗→车床"这类单字错误时调到 10–15；默认 30 会漏掉 MER 5–30% 这一段 | 30 |
| `--final-n` | 每个 bkey 最终进包几条 | 10 |

---

## 三、脚本目前筛不了的（已知缺口）

这些情况，脚本只能"信任原评分 + 按 subtask 粗分"，失败模式需要人工看，或者以后再扩展规则：

1. **工具调用轨迹内部的错误类型**：选错工具、参数错、违反业务策略、多轮中途放弃。BFCL 的"工具名对不对 / 参数对不对"其实可以用规则判，后续值得补；Tau 系的多轮轨迹目前只能人看。
2. **双工时序类错误**：抢话早了多久、该附和时没附和。文本输出里没有时间信息，需要时间轴字段。
3. **对错取决于音频内容的题**：会标成 `needs_audio`，只能人听。
4. **空输出的原因**：是链路没把音频送进去，还是模型没回应，要查 events。
5. **MMAU 的 GT 是选项文本时**：需要 ledger 里有选项列表，才能把文本映射回字母。

---

## 四、第一次在真实数据上跑完后的验收

1. **audit**：有没有意外被跳过的 bkey（看 ⚠ 和 warnings）。特别看三类：拒识 / 长暂停（应显示 `authority=rule:silent_is_pass`）、vcb judge 型、ambiguous。
2. **根因分布**：**某个 bkey 的评测侧占比 100%，先怀疑配置**（漏了 `trust_scorer`，或字段名不对），再怀疑评测本身有 bug。真实的评测 bug 很少会让所有 badcase 都中招。
3. **抽查**：每个子能力抽 5–10 条精选 case，打开看、听音频，确认"判成 badcase"这件事本身是对的。重点抽拒识和长暂停：这两类方向一旦反了，整个结论都会反。
4. **样本数**：每个子能力对应的 bkey 数，与预期一致（SoulX-FDB-zh 4 个、拒识（接受）6 个）。
