---
name: badcase-pipeline
description: Omni 全模态评测 badcase/pass 样本流水线。从 DI 批跑产物（raw_out）选取候选样本，经规则分诊与模型盲判区分"模型真错"与"评测侧问题"（评分误判、GT 错、数据坏），精选后组装样本包、注册到 EvalBoard「样本探查」看板，并经统一 API（:9430）分析。触发场景：badcase 选取/组包、pass 样本包、ckpt 回归对比、新批次上看板、badcase 分析查询、评分器/GT 问题排查。
---

# badcase-pipeline：评测 badcase / pass 样本流水线

## 0. 先想清楚：badcase 不等于低分

选取脚本只能看到"分数低"，而一条低分 case 可能来自六种原因，只有第一种是模型问题：

| 根因 | 实例 | 谁能判 |
|---|---|---|
| 模型真错 | 选了错误选项；转写把"车窗"听成"车床" | 规则 / 模型 judge |
| 评分器误判 | 输出"答案是B，因为……"，GT 为"B"，解析器只认裸字母，判 0 | 规则（选择题）/ 模型 judge |
| GT 错或缺 | GT 有错字；`bfcl_v3` 的 GT 是结构化 list | 规则（缺失/结构化）/ 模型 judge（错字） |
| 规范化口径差 | REF「调到二十六度」HYP「调到26度」，MER 50% | 模型 judge |
| 数据坏 / 链路丢 | 空输出其实是音频没送进去；音频截断 | 人（听音频、查 events） |
| 本就该如此 | 附和/打断/拒识类任务里，沉默可能是正确行为 | 任务定义（需向用户确认） |

如果不区分，badcase 包里会混进评测侧的 bug，拿去分析模型就会得出错误结论。所以流水线分四层，每层只做自己能可靠完成的事：

1. **脚本选取**：判断字段可信、按分层抽出有代表性的候选池。
2. **规则分诊**：确定性能判的根因直接判，零成本。
3. **模型盲判**：规则判不了的，交给 judge 模型；judge 不看原分数，独立判断。
4. **人工**：校验 judge、听音频、把失败描述归纳成分类。

| 步骤 | 输入 → 输出 | 卡口 | 详见 |
|---|---|---|---|
| 1. 选取候选池 | raw_out → cand.json | audit 人工确认 | §2 |
| 2. 分诊 + 判因 + 精选 | cand.json → plan.json + eval_issues.json | 根因分布确认；新 bkey 族需人工校验 judge | §3 |
| 3. 组包 | plan.json → 样本包 | fail 明细 | §4 |
| 4. 注册 | raw_out + 包 → 看板 | health 检查 | §5 |
| 5. 分析 | 看板 / triage_all.json → 失败分类；报告交给报告 skill | — | §6 |

```mermaid
flowchart TD
    A[raw_out<br/>_metrics + _ledgers] --> B{前置核验<br/>bkey 一致 / 字段齐全}
    CAP[capabilities.json<br/>子能力 → bkey / 判定规则] -->|caps_to_rules.py| R[rules.json<br/>拒识·长暂停: 说话即错]
    B --> C[select_samples.py<br/>权威字段三重校验 + 分层 MMR 抽候选池]
    R --> C
    BASE[baseline raw_out<br/>可选: 回归对比] -.->|--baseline 只留翻转 case| C
    C --> G1{⛔ 卡口 1<br/>audit 确认}
    G1 --> D[triage_judge.py ① 规则分诊<br/>选择题抽取 / ASR 数字规范化 / 复读 / 抢话形态 / GT 缺失]
    D -->|规则判不了| E{要接 judge 吗?}
    E -->|默认 --no-judge<br/>或已被 LLM 打过分| U[unverified<br/>信任原评分]
    E -->|规则打分的开放题| J[② 模型盲判<br/>不看原分数]
    J --> H[人工校验 judge<br/>--calib 一致率 ≥ 0.8]
    D --> S[根因]
    U --> S
    H --> S
    S -->|模型侧| P[plan.json<br/>按失败模式分层精选]
    S -->|评测侧| I[eval_issues.json<br/>修评分器 / GT]
    S --> T[triage_all.json<br/>全量根因分布]
    P --> G2{⛔ 卡口 2<br/>评测侧占比确认}
    G2 --> K[assemble_pkg.py 组包]
    K --> L[看板注册 :9430]
    T --> M[交给报告 skill<br/>plan.json / triage_all.json / eval_issues.json]
    CAP --> M
    L --> N[人工: 听音频 · 逐条记 · 归类成失败分类表]
    M --> N
    N -.->|分类表作为下一批的分层依据| C
```

## 1. 前置检查（每次先做）

### 1.1 环境约定

- 本机没有 moxing。凡需访问 OBS 的步骤，一律用 `/yes/envs/glm/bin/python`（已装 boto3，ads 只读 AK 见 `vllm-mola_asreval_20261019/di/obs_creds.sh`）。
- 纯本地步骤用系统 `python3`。
- judge 模型：**默认不需要**，先用 `--no-judge` 跑（见 §3.0）。确实要接时，需要一个 OpenAI 兼容接口（`--api-base`、`--model`；key 放环境变量 `JUDGE_API_KEY`），且 **judge 不能与被测模型同源**，否则会偏袒自家输出，脚本会按名字拦截。

### 1.2 输入核验

```
<raw_out>/
  _metrics/<bkey>.json               # per-case 模型输出 + 重评分
  _ledgers/<bkey>/ledger_v1.0.jsonl  # gt / user prompt / audio uri / subtask
```

1. `_metrics` 与 `_ledgers` 的 bkey 集合一致；
2. 任抽一个 bkey，确认 samples 内含 `raw_output` / `score` / `correct`，并记下有没有 `scoring_status`（评分是否跑成功，分诊会用到）；
3. 抽一个 ledger，确认 `metadata.subtask` 是否存在（分层依赖它；缺失时脚本退化为按失败签名分层）。

### 1.3 术语

| 术语 | 含义 |
|---|---|
| `bkey` | benchmark 任务键（如 `mmau_mmau`、`wenet_net`） |
| 权威字段 | 用来判对错的字段：`score` 或 `correct`，由 §2 的三重校验决定 |
| 候选池 | 选取脚本产出、待判因的样本集（cand.json） |
| 锚点 | 输出规范化后与 GT 一字不差的样本，必然是 pass，用来检验字段方向 |
| 根因 | §3 产出的 `triage.root_cause`，区分模型侧与评测侧 |
| 失败描述 | judge 写的 ≤15 字行为描述（如"拒答""答非所问"），是开放编码的初稿 |
| MER | ASR 类 bkey 的 per-case 错误率近似（zh 字级 / en 词级） |
| 类标签 | `judge_wrong`（低分）、`pass`、`no_speech`（空输出）。注意：`judge_wrong` 只表示"打分低"，是否模型错看 `triage.root_cause` |

## 2. 选取：raw_out → 候选池 cand.json

引擎 `web/scripts/select_samples.py`（v2）。对每个 bkey 自动判定三件事。

### 2.1 权威字段：三重校验，而不是只比均值

**这个检查在检查什么。** 它比较的是同一次评测的两本账：官方汇总的 `metrics.accuracy`，和脚本从逐条字段重算的值。模型差时两者都低、照样对得上，所以它衡量的不是模型好坏，而是"这个字段的方向、口径与官方一致吗"。例如 `fdb_user_backchannel_zh` 的 score 均值 0.965、accuracy 0.035，说明 score 反着记。

**只比均值有三个漏洞**，所以 v2 做三重校验：

1. **多口径重算**：{全量 / 剔除评分失败} × {整体平均 / subtask 宏平均}，judge 型另试 {score/5, score≥4 的占比}。任一口径对齐即可，命中口径记在 `matched_by`。
   - 堵的漏洞：judge 0–5 分的均值（如 2.9）永远对不上 [0,1] 的 accuracy（如 0.48）；accuracy 按 subtask 宏平均时，逐条均值会合法地对不上。旧版这两种都会误杀整个 bkey。
2. **逐条方向一致率**：score 与 correct 都在时，逐条比是否同向；`agree < 0.5` 即方向相反。
3. **锚点校验**：锚点必然是 pass；权威字段若把锚点大多判成 bad（< 0.8），撤销该字段。
   - 堵的漏洞：accuracy≈0.5 时，反向字段的均值 1−0.5 恰好也等于 0.5，会被误当权威。无锚点、无交叉字段可裁决时，标 ambiguous 警告。

另外：缺失的 `correct` 不再当作 False 计数（旧版会算出 correct_ratio=0，模型极差的 bkey 会因此误对齐）。

### 2.2 评分尺度

| 值集 | 尺度 | pass 判定 |
|---|---|---|
| ⊆ {0,1} | binary | ≥ 0.5 |
| (0,1] 连续 | unit | ≥ 0.5（旧版误归 judge5，全部判 bad） |
| max ≤ 5 | judge5 | ≥ `--judge-pass`（默认 4） |
| 其他 | other | 不用 score 判，退回 correct |

mmau / ifeval / voicebench 系都是 0/1，不要套 judge ≥ 4 的阈值。

### 2.3 ASR 特判

`wenet×2 / librispeech / twinkstart×2` 另算 per-case MER（TextNorm 近似，非产线逐位口径）：bad ≥ `--asr-bad`（30%），pass ≤ `--asr-pass`（5%）。

**已知盲区**：5%–30% 的中间段既不算 bad 也不算 pass，而"车窗→车床"这种单字替换（MER 25%）正落在这里，很可能是最常见的真实错误。要看它就把 `--asr-bad` 调到 10–15，再靠 §3 判因去掉规范化假错。

### 2.4 分层抽样，而不是"最差 top-N"

旧做法取最低分的 N 条，有两个问题：二值打分时所有 bad 并列 0 分，稳定排序等于"取文件里前 N 条"，结果 10 条全来自同一个 subtask、同一种错法；而极端最差往往是数据问题，不代表典型错误。

v2：先按 subtask 分层（单 subtask 时按失败签名：偏短/偏长/复读/语种错配）；每层保底 1 条，剩余名额按 sqrt(层大小) 分配（`--alloc prop|sqrt|uniform`）；层内用 MMR 挑选：每一步在"错得严重"和"跟已选的不像"之间权衡（`--lam`，默认 0.5）。

### 2.5 执行

**候选池要比最终条数大**，留给 §3 按根因筛：

```bash
python3 web/scripts/select_samples.py \
    --base <raw_out> --out <cand.json> \
    --top-n 50 --seed 42 \
    --exclude-dirs <同一 ckpt 的已有包>
```

- bad 池不大（几百条以内）时，直接把 `--top-n` 设得比池子大（如 300），等于全量判因。这样 §3 输出的根因比例是总体比例；否则只是非随机候选的比例，只能作参考（报告里会标注）。
- `--exclude-dirs` **只排除同一 ckpt 已组过包的 case**。跨 ckpt 排除会让你永远看不到同一条 case 的前后对比。

**回归对比模式**（看"这次改坏了什么"）：

```bash
python3 web/scripts/select_samples.py --base <新 raw_out> --baseline <旧 raw_out> \
    --out <cand.json> --top-n 50
```

bad 类只保留"baseline 判 pass、本批判 bad"的翻转 case。

**非 accuracy 指标的 bkey**（拒识 FPR_speak、长暂停 TOR）：这类 bkey 没有 accuracy，三重校验必然对不上，会被整体跳过；而且它们的对错和普通任务相反：**沉默是对的，说话是错的**。用 `--rules` 按任务定义判对错，规则从子能力配置导出，保证只有一个来源：

```bash
python3 web/scripts/caps_to_rules.py --caps config/capabilities.json --out rules.json
python3 web/scripts/select_samples.py --base <raw_out> --out <cand.json> --top-n 300 --rules rules.json
```

规则类型：`silent_is_pass`（输出为空 = 对，有输出 = 错；输出是时间轴 JSON 时，用 `speak_field` 指定"是否发声"的字段）；`field`（按指定字段和阈值判，如 `{"type": "field", "field": "takeover", "pass_if": "==", "value": 0}`）。baseline 该 bkey 的权威字段没通过校验时，自动不做翻转过滤并报警。用户提出"只看英文 / 只看某 subtask"等新维度时，同样在这一步加过滤，不要事后从包里删样本。

> ⛔ **卡口 1：audit 确认。** 把每个 bkey 的 `accuracy / scale / authority / matched_by / n_anchors / agree_score_vs_correct / warnings` 呈给用户，重点说明：
> - 被跳过的 bkey（权威字段未通过）怎么处理；
> - ambiguous 的 bkey 是否人工抽查方向；
> - `coverage.bad.pool_by_stratum` 里某层是否占压倒性多数（说明该 subtask 是主要短板，这是结论，不是抽样问题）。

## 3. 分诊 + 判因 + 精选：cand.json → plan.json

### 3.0 要不要接 judge 模型

先分清两个 judge：评测链里的 judge 负责**打分**，它的结论就是 `score`；这里的 judge 负责**复核分数打得对不对**，是第二意见。评测链"已经 judge 过"不能替代复核，但大多数情况下复核用规则就够了，不用接模型：

| bkey 的打分方式 | 复核方式 | 要不要接 judge |
|---|---|---|
| 选择题精确匹配（mmau 等） | 规则抽选项：输出"答案是B"却判 0 → 解析器误判 | 不要 |
| ASR MER | 规则：复读、语种错配、续写；中文数字统一成阿拉伯数字后再比（"二十六度"↔"26度"） | 不要 |
| 已由 LLM judge 打分（vcb judge 型等） | 再找一个 judge 只会得到"两个 judge 意见不同"，仍要人审。所以用 `--llm-scored-bkeys` 沿用原分数，原 judge 的理由（若 metrics 里有 reason 类字段）直接作为失败描述 | 不要 |
| 规则打分的开放式答案（如 ifeval 的规则检查、关键词匹配） | 规则无法判断语义是否正确 | **只有这类值得接** |

推荐做法：先 `--no-judge` 跑一遍。规则判不了的样本标为 `unverified`，仍然进模型包，按选取阶段的分层抽样。如果之后某个 bkey 的 unverified 很多，又怀疑评分器有问题，再对那个 bkey 接 judge。

```bash
python3 web/scripts/triage_judge.py --plan <cand.json> --out <plan.json> \
    --no-judge --llm-scored-bkeys "vcb_*" --trust-scorer-bkeys "bfcl_v3*,tau2*,..." --final-n 10 \
    --silence-ok-bkeys <沉默可能正确的 bkey，逗号分隔>
```

`--llm-scored-bkeys` 与 `--trust-scorer-bkeys` 的取值由 `caps_to_rules.py` 从 `capabilities.json` 打印出来，直接复制即可，不要手写两份。

接 judge 时的完整命令：

```bash
python3 web/scripts/triage_judge.py --plan <cand.json> --out <plan.json> \
    --api-base http://<host>:<port>/v1 --model <judge 模型> \
    --evaluated-model <被测模型名> --final-n 10 --workers 16 \
    --silence-ok-bkeys <沉默可能正确的 bkey，逗号分隔>
```

先用 `--dry-run` 看几条 prompt 是否合理，再正式跑。judge 结果有缓存（同目录 `judge_cache.jsonl`），重跑不重复计费。

### 3.1 规则分诊（确定性）

| 规则 | 条件 | 根因 |
|---|---|---|
| scoring_status | 含 fail / error / timeout 等 | `scorer_error` |
| GT 缺失 / 结构化 | GT 为空，或是 list / JSON | `gt_missing` |
| 输出非文本 | 输出是 JSON（如 fdb 的 chunk 时间轴） | `unjudgeable_keep`：文本 judge 看不懂，保留原评分 |
| 结构化是正常形态 | bkey 在 `--trust-scorer-bkeys` 里（工具调用：BFCL、Tau-2、Tau Voice、FDB V3） | 不走上面两条，`unverified`：信任原评分器。**不加这个参数，这类 bkey 的 badcase 会全部被误判成评测侧问题** |
| 选择题抽取 | GT 是单个字母，能从输出抽出选项 | 抽到正确选项却判错 → `scorer_false_negative`；抽到错误选项却判对 → `false_pass`；选错 → `model_error` |
| ASR 数字写法 | 中文数字转阿拉伯数字后与 GT 基本一致（MER ≤ 5%） | `scorer_false_negative` |
| ASR 形态 | 复读循环 / 语种错配 / GT 完整出现在输出里且明显更长（转写后续写） | `model_error` |
| 空输出 | bkey 在 `--silence-ok-bkeys` 里 | `expected_silence` |
| 抢话形态 | bkey 走 `silent_is_pass` 规则且模型说话了 | `model_error`，细分为"附和式插话（短应答）""复述用户话语""完整抢答" |
| 空输出 | 其他 | `needs_audio`：要查 events 区分"链路没送音频"和"模型没回应" |

`--silence-ok-bkeys` 由任务定义决定，每批向用户确认，不要猜。附和、打断、拒识类任务通常属于此类。

### 3.2 模型盲判（仅接 judge 时；规则判不了的部分）

judge **不看原分数**，只看题目、GT、输出，独立给出：

- `verdict`：对 / 部分对 / 错 / 判不了；
- `gt_plausible`：GT 本身是否自洽；
- `needs_audio`：是否必须听音频；
- `failure_mode`：≤15 字的行为描述。

盲判的原因：如果先告诉 judge "这条被判了 0 分"，它会倾向于去找错误来附和。之后由脚本把原判定和盲判结果对照，得出根因：

| 原判定 | 盲判 | 根因 | 去向 |
|---|---|---|---|
| bad | 错 / 部分对 | `model_error` | 模型包 |
| bad | 错，且 GT 不自洽 | `gt_suspect` | eval_issues |
| bad | 对（原评分是规则 / 二值） | `scorer_false_negative` | eval_issues |
| bad | 对（原评分本身是 LLM judge） | `judge_disagree`：两个 judge 打架，不能断定谁对 | eval_issues，人审 |
| bad | 判不了 / 需音频 | `needs_audio` | 模型包（排在后面），需人听 |
| bad | 未判（`--no-judge` 或 LLM 已打分的 bkey） | `unverified`：信任原评分 | 模型包，按选取分层抽 |
| pass | 错 | `false_pass`（或 `judge_disagree`） | eval_issues |
| ASR bad | 仅规范化差异 | `scorer_false_negative` | eval_issues |

两个 prompt 的具体例子：

- **ASR**：REF「调到二十六度」HYP「调到26度」→ equivalent（不算错）；REF「打开车窗」HYP「打开车床」→ 真实识别错误，failure_mode 写"近音字替换"。
- **问答**：GT「B」，输出「答案是B，因为音频里提到了……」→ correct。题目只有"听音频，选择正确选项"、判断全靠音频内容时 → cannot_judge，needs_audio=true，不许猜。

pass 类默认不判（成本考虑）。要查假阳性时加 `--judge-pass`：抽查 pass 的 case 是否真的对。新接入的 bkey 建议至少做一次。

### 3.3 judge 的边界（它也判不了的）

- **听不到音频**：凡对错取决于音频内容的，只能标 `needs_audio`，交人听。如果要让音频模型做 judge，同样不能与被测模型同源。
- **对 LLM judge 打的分没有裁决权**：原评分就是 LLM judge 时，盲判不同意只说明两个 judge 有分歧，归 `judge_disagree` 由人审。
- **失败描述只是初稿**：措辞会漂移（"拒答""拒绝回答""不回答"），脚本只做粗聚类，正式分类要人工归纳（§6）。
- **跨 case 的模式看不见**：judge 一次只看一条。例如"选错时 79% 选的是 A"（位置偏好），只有跨 case 统计才能发现，脚本在根因分布里会自动报 ⚠。

### 3.4 精选与分流

- 模型包（plan.json）：每 bkey 的 `model_error` 先按失败描述聚类，再按 sqrt 配额抽 `--final-n` 条；不足时用 `needs_audio` 补。pass 优先取已确认的。每行附 `triage` 字段（根因、失败描述、方法、judge 模型、prompt 版本）。
- 评测侧问题（eval_issues.json）：**全量保留，不抽样**。这是给评测工程的修复清单：修解析器、补 TextNorm、改 GT。如需上看板，包成 `{"plan": [...]}` 后同样走 §4 组包，单独成包。
- triage_all.json：候选池全部明细 + 每 bkey 根因分布。

> ⛔ **卡口 2：根因分布确认。** 把每个 bkey 的 `eval_side_ratio`（评测侧占比）、根因计数、⚠ 位置偏好呈给用户。
> - 某 bkey 评测侧占比高（经验上 > 20%）时，**这个 bkey 的分数本身就不可信**，应先修评测再谈模型。例：模拟数据里一个 ASR bkey 的 badcase 100% 是"二十六 vs 26"这类规范化差异。
> - 比例只有在 `is_full_population=true` 时才是总体比例。

### 3.5 人工校验 judge（新 bkey 族 / 改 prompt 后必做）

脚本会按根因分层抽出 `human_check.jsonl`（默认 40 条）。人工填 `human_root_cause` 后：

```bash
python3 web/scripts/triage_judge.py --calib human_check.jsonl
```

输出每种根因的一致率和主要分歧。**某根因一致率 < 0.8，就不要自动信 judge 在这个根因上的判断**：要么改 prompt 重跑，要么把该根因的 case 全部转人工。校验结果记进交付报告。

## 4. 组包：plan.json → 样本包

组装器 `web/scripts/assemble_pkg.py` 是通用的，plan 字段与旧版兼容。

1. 在 plan.json 中补 `batch` / `model` / `ckpt` 三个字段（供写入 meta）。
2. 执行（后台跑，幂等）：

   ```bash
   /yes/envs/glm/bin/python web/scripts/assemble_pkg.py \
       --plan <plan.json> --out <包目录> --workers 24
   ```

每个 case 一个文件夹，固定五件：`input.wav`（16k mono pcm16）、`gt.txt`、`input.txt`（与 gt 相同则省略）、`meta.json`（`badcase_class` = 类标签）、`messages.json`。`triage` 字段需要写进 meta.json：若 assemble_pkg 目前不透传未知字段，要补一行透传。

音频两条通道，自动回退：先从 `obs://yw-2030-gy/.../huwenxin/data/<rel>` 直拉 wav；失败则从 `streaming_converted/<bkey>/realtime_converted/events/` 做 base64 解码（116 个 bkey 全覆盖），system prompt 取自 events 的 `session.update.instructions`。

完成后检查：

- 中断重跑安全；看 `ok/fail` 与 `fails.json`，fail > 0 时逐条确认原因。
- 抽查 3 个 case（音频可播、gt/output 非空、meta 齐全，含 triage），`du -sh` 报体积。
- `needs_audio` 的 case 组包后优先人工听，回填结论。

> 历史固定规则脚本（a5e578ee 批遗留，仅参考，勿再扩展）：`/cache/x30087116/badcase_a5e578ee_20261020/build_badcase_pkg.py`、`web/scripts/build_pass_pkg.py`。

## 5. 看板注册（样本探查页）

1. **全量索引**：`sample_server.py` 的 `METRICS_SOURCES` 加入本批 raw_out，删除索引缓存 `sample_metrics_index.json.gz`，重启服务。未组包 case 标「未组包」，音频点播时从 OBS 现拉并缓存到 `sample_audio_cache/`。
2. **组包目录**：加入 `DEFAULT_ROOTS` 或环境变量 `SAMPLE_ROOTS`（冒号分隔），重启：

   ```bash
   # 先按 :9430 端口找到 pid 并 kill，然后：
   nohup python3 web/scripts/sample_server.py > /tmp/sample_server_9430.log 2>&1 &
   ```

   首次启动构建全量索引需 1–3 分钟；构建失败不影响服务，只剩包内数据。
3. **批次登记**：`web/scripts/batch_registry.json` 增加：

   ```json
   "<batch_id>": {
     "label": "DI 批 <job> · <date>",
     "venue": "DI 集群 | 开发机 <机器名>",
     "date": "YYYY-MM-DD",
     "job": "<job_id>",
     "note": "一句话说明"
   }
   ```

   开发机跑的批，`venue` 必须写明机器名（用户明确关心跑批地点）。

验证：`curl :9430/api/health`（看 `root_stats` 与 `metrics_index.unpacked_cases`）；看板 `/badcases` 按新批次筛选；抽一条未组包 case 点播音频，验证懒拉通道。

**注意**：看板目前按类标签筛选。要按根因筛（如"只看模型侧"），需要在 `/api/facets` 加 `triage.root_cause` 维度，这需要改服务端，未实现前用 API 拉列表后本地过滤。

## 6. 分析：从个例到失败分类

### 6.1 查询

| 接口 | 用途 |
|---|---|
| `GET /api/facets?family=VCB` | 维度计数（联动筛选） |
| `GET /api/cases?class=judge_wrong&bkey=...&q=关键词&max_score=2` | 条件列表 |
| `GET /api/case?root=0&class=..&bkey=..&case_id=..` | 单条详情 |
| `GET /api/audio?...` | 音频（Range 流式） |

也可以直接读包（pandas 遍历 `meta.json`）或读 `triage_all.json`。

### 6.2 方法：先逐条记、再归类、直到不出新类

judge 的 `failure_mode` 是开放编码的初稿，正式分析按三步走：

1. **逐条记**：人读样本（含听音频），每条写一句"错在哪"，只描述行为，不猜原因。有疑问先记第一个出错点。
2. **归类**：读完几十条后，把描述合并成一张失败分类表。例如"拒答""说不知道""要求重复问题"可能都归为"回避作答"。LLM 可以帮着提议合并，但合并结果要人确认：它可能把"音频截断导致漏转"和"模型提前结束"合成一类，而这两者一个是数据问题，一个是模型问题。
3. **饱和**：用分类表去标下一批样本；连续一批没有冒出新类，就算饱和，可以停。

分类表存成文件（如 `taxonomy_<bkey族>.md`）。下一批次在 §2 里按这张表分层抽样，取代粗粒度的 subtask。

### 6.3 交给报告 skill

报告由单独的报告 skill 负责，本 skill 只提供素材：

| 文件 | 内容 | 报告里怎么用 |
|---|---|---|
| `plan.json` | 精选样本（每行带 `triage`）+ `audit`（每 bkey 判定口径、警告、分层覆盖） | 失败模式的具体例子；判定口径说明 |
| `triage_all.json` | 候选池全部 case 的根因 + `by_bkey` 根因分布（`eval_side_ratio`、`mcq_wrong_pick`、`is_full_population`） | 各类错误占比；评测侧占比；位置偏好等跨 case 模式 |
| `eval_issues.json` | 评测侧问题全量 | 单列"评测侧问题"，不算模型的错 |
| `config/capabilities.json` | 子能力 → bkey、指标名、方向、门槛 | 按子能力组织章节；判断是否达标 |

交接时提醒报告方三点：`triage.root_cause` 不在模型侧的 case 不要算进模型问题；`is_full_population=false` 的比例只能说"候选中"；`unverified` 表示信任原评分、未经复核。

### 6.4 统计与个例分工

- 某类错误"有多少"，看全量统计（`triage_all.json` 的根因分布、失败描述计数），不要从 10 条样本里估。
- 样本包负责"长什么样"：每一类给出具体例子，用来理解和汇报。

## 7. 口径红线（引用任何分数前必读）

本节只保留方法论；具体批次现象见附录，不要直接沿用旧结论。

1. **单位与分母要实测**：ASR corpus 类分数可能是原始小数（可 > 1）或 ×100；分母是否只含"有输出的样本"因链而异。引用前两种口径各算一遍，与看板对齐。
2. **字段类型不稳定**：`score` / `correct` 出现过 int、字符串 `'0'/'1'`、bool；`correct` 可能与官方相反。统一用引擎的三重校验，不要手写 per-bkey 硬编码。
3. **假分 / 无分项随批次变化**：新批次以 audit 自动核对为准。
4. **output 形态按类区分**：空输出、chunk 时间轴 JSON、结构化 list 都出现过，做文本 diff 前先判形态。
5. **badcase 比例**：引用"X% 的 badcase 是某类"前，确认 `is_full_population=true`；否则注明是候选样本比例。
6. **judge 结论可追溯**：引用 judge 的判定时注明 `judge_model` 与 `prompt_version`，以及该根因的人工校验一致率。

## 8. 交付报告

组包完成后汇报：

- 包路径、各类标签 / 各 bkey 计数、总条数、体积、fail 明细、是否已上看板（批次 label）；
- **每 bkey 根因分布与评测侧占比**，评测侧占比高的 bkey 单独点名，附 eval_issues.json 路径；
- ⚠ 跨 case 模式（如位置偏好）；
- judge 模型、prompt 版本、人工校验一致率（未做校验要写明"未校验"）；
- `needs_audio` 待人工听的条数；
- 交给报告 skill 的文件路径（plan.json / triage_all.json / eval_issues.json）。

## 附录：历史口径案例（快照，仅作背景，勿直接沿用）

以下来自 2026-10-20 a5e578ee 批实测，新批次必须重新核对。括号里是在新流程下的对应处理。

- `evaluate_direct.py` 节点直评链的 corpus_wer 是原始小数（wenet_net 7.5593 = 755.9%）；总表看板 ×100 是正确百分化，勿当 bug 修。其分母只含"有输出的样本"（`evaluate_direct.py:196` 的 `and parsed` 跳过空输出），全分母口径需自己补算。
- `fdb_user_backchannel_zh`：score 与官方 accuracy 相反（0.965 vs 0.035）。（三重校验中逐条一致率为 0，锚点裁决选 correct；输出是 chunk 时间轴 JSON，分诊为 `unjudgeable_keep`。）
- vcb judge 型约 18 个 bkey：score 与 correct 都与 accuracy 差 0.05–0.1（重评分二值化 vs per-case 聚合口径差），旧引擎跳过、沿用旧包。（新引擎的多口径重算可能已能对齐，先重跑看 `matched_by`；仍对不上再与用户确认，不要默认沿用旧包，旧包对应的是旧 ckpt。）
- `voicebench_wildvoice`：display 0（官方 20.0；per-case correct 全 false，只能看 no_speech）。（这正是评分侧问题的典型：逐条字段全 false 却有官方分，应列入 eval_issues 排查评分链。）
- `bfcl_v3`：无分（形态缺口），GT 是结构化 list（1068 条）。（分诊为 `gt_missing`，需专用评分器。）
- `ifeval`：NLTK 假零问题已修复（a5e578ee 批 acc = 53.6%，可正常选取）。（同类"假零"问题今后应由 `scorer_false_negative` 的比例异常提前暴露。）
- 形态：`no_speech` 类 output 为空；fdb backchannel 类 output 是 chunk 时间轴 JSON。
